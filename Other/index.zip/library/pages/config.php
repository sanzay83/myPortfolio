<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'sanzay83_san');
   define('DB_PASSWORD', '{9+AEWXZaWq.');
   define('DB_DATABASE', 'sanzay83_Library');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>